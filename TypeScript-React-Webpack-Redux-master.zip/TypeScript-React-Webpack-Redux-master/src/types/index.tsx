export interface demo {
  languageName: string;
  enthusiasmLevel?: number;
}
export interface StoreState {
  demo?: demo;
}