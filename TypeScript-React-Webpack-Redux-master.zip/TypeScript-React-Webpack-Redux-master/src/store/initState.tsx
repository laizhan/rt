export default {
  demo: {
    enthusiasmLevel: 1,
    languageName: 'TypeScript',
  }
}