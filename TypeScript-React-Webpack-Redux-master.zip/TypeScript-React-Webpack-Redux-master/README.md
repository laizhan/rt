# TypeScript-React-Webpack-Redux
一个完整的TypeScript + React + React-Router + Redux + Webpack开发环境的demo

完整教程请看[从零开始配置TypeScript + React + React-Router + Redux + Webpack开发环境](http://www.cnblogs.com/baqiphp/p/7647912.html)